# Analytics-Vidya-Job-Hacathon-Approach

**Data set link:** 

https://datahack.analyticsvidhya.com/contest/job-a-thon-september-2021/?utm_source=datahack&utm_medium=navbar#About
